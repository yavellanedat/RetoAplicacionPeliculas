package com.example.demo.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.proyectopeliculas.Actor;

public interface IActorrepositorio extends JpaRepository<Actor, Integer> {

}