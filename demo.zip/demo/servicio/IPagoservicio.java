package com.example.demo.servicio;

import java.util.List;

import com.example.demo.proyectopeliculas.Pago;

public interface IPagoservicio {
	
	List<Pago> listar();
	Pago registrar(Pago Pago);
	Pago actualizar(Pago Pago);
	void eliminar(Integer codigo);
	Pago ListarPorId(Integer codigo);

}