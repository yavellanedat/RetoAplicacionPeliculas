package com.example.demo.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.proyectopeliculas.Rol;

public interface IRolrepositorio extends JpaRepository<Rol, Integer> {


}