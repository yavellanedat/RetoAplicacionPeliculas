package com.example.demo.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.proyectopeliculas.Director;

public interface IDirectorrepositorio extends JpaRepository<Director, Integer> {

}