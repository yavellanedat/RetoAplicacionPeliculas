package com.example.demo.servicio;

import java.util.List;

import com.example.demo.proyectopeliculas.Usuario;

public interface IUsuarioservicio {
	
	List<Usuario> listar();
	Usuario registrar(Usuario Usuario);
	Usuario actualizar(Usuario Usuario);
	void eliminar(Integer codigo);
	Usuario ListarPorId(Integer codigo);

}
