package com.example.demo.servicio.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.proyectopeliculas.Pago;
import com.example.demo.repositorio.IPagorepositorio;
import com.example.demo.servicio.IPagoservicio;

@Service 
public class Pagoservicioimpl implements IPagoservicio {
	

	@Autowired
	IPagorepositorio repo;

	@Override
	public List<Pago> listar() {
		return repo.findAll();

	}

	@Override
	public Pago registrar(Pago Pago) {
		return repo.save(Pago);

	}

	@Override
	public Pago actualizar(Pago Pago) {
		return repo.save(Pago);
	}

	@Override
	public void eliminar(Integer codigo) {
		repo.deleteById(codigo);
		
	}

	@Override
	public Pago ListarPorId(Integer codigo) {
		return repo.findById(codigo).orElse(null);

	}


}