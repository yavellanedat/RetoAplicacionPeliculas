package com.example.demo.servicio.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.proyectopeliculas.Categoria;
import com.example.demo.repositorio.ICategoriarepositorio;
import com.example.demo.servicio.ICategoriaservicio;

@Service 
public class Categoriaservicioimpl implements ICategoriaservicio {
	

	@Autowired
	ICategoriarepositorio repo;

	@Override
	public List<Categoria> listar() {
		return repo.findAll();

	}

	@Override
	public Categoria registrar(Categoria Categoria) {
		return repo.save(Categoria);

	}

	@Override
	public Categoria actualizar(Categoria Categoria) {
		return repo.save(Categoria);
	}

	@Override
	public void eliminar(Integer codigo) {
		repo.deleteById(codigo);
		
	}

	@Override
	public Categoria ListarPorId(Integer codigo) {
		return repo.findById(codigo).orElse(null);

	}


}