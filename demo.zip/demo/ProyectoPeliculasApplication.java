package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoPeliculasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoPeliculasApplication.class, args);
	}

}
