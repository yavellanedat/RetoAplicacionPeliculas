package com.example.demo.servicio.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.proyectopeliculas.Director;
import com.example.demo.repositorio.IDirectorrepositorio;
import com.example.demo.servicio.IDirectorservicio;

@Service 
public class Directorservicioimpl implements IDirectorservicio {
	

	@Autowired
	IDirectorrepositorio repo;

	@Override
	public List<Director> listar() {
		return repo.findAll();

	}

	@Override
	public Director registrar(Director Director) {
		return repo.save(Director);

	}

	@Override
	public Director actualizar(Director Director) {
		return repo.save(Director);
	}

	@Override
	public void eliminar(Integer codigo) {
		repo.deleteById(codigo);
		
	}

	@Override
	public Director ListarPorId(Integer codigo) {
		return repo.findById(codigo).orElse(null);

	}


}
