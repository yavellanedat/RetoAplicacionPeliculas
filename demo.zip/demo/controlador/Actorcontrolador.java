package com.example.demo.controlador;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.demo.proyectopeliculas.Actor;
import com.example.demo.servicio.IActorservicio;

@RestController
@RequestMapping("/Actor")
public class Actorcontrolador {
	
	@Autowired
	IActorservicio service;
	
	@GetMapping
	public ResponseEntity<List<Actor>> listar(){
		List<Actor> obj = service.listar();
		return new ResponseEntity<List<Actor>>(obj, HttpStatus.OK);
	}
	
	@PostMapping
	public ResponseEntity<Void> registrar(@RequestBody Actor actor){
		Actor obj = service.registrar(actor);
		
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdActor()).toUri();
		
		return ResponseEntity.created(uri).build();
	}
	
	@PutMapping
	public ResponseEntity<Actor> actualizar(@RequestBody Actor actor){
		Actor obj = service.actualizar(actor);
		return new ResponseEntity<Actor>(obj, HttpStatus.OK);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> eliminar(@PathVariable("id")Integer id) throws Exception{
		Actor obj = service.ListarPorId(id);
		if(obj == null) {
			throw new Exception("No se encontro ID");
		}
		service.eliminar(id);
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Actor> listarPorId(@PathVariable("id") Integer codigo) throws Exception{
	Actor obj = service.ListarPorId(codigo);
	if(obj == null) {
		throw new Exception("No se encontro ID");
	}
	return new ResponseEntity<Actor>(obj, HttpStatus.OK);
}
}
