package com.example.demo.servicio.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.proyectopeliculas.Rol;
import com.example.demo.repositorio.IRolrepositorio;
import com.example.demo.servicio.IRolservicio;

@Service 
public class Rolservicioimpl implements IRolservicio {
	

	@Autowired
	IRolrepositorio repo;

	@Override
	public List<Rol> listar() {
		return repo.findAll();

	}

	@Override
	public Rol registrar(Rol Rol) {
		return repo.save(Rol);

	}

	@Override
	public Rol actualizar(Rol Rol) {
		return repo.save(Rol);
	}

	@Override
	public void eliminar(Integer codigo) {
		repo.deleteById(codigo);
		
	}

	@Override
	public Rol ListarPorId(Integer codigo) {
		return repo.findById(codigo).orElse(null);

	}


}
