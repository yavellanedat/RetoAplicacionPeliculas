package com.example.demo.servicio.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.proyectopeliculas.Pelicula;
import com.example.demo.repositorio.IPelicularepositorio;
import com.example.demo.servicio.IPeliculaservicio;

@Service 
public class Peliculaservicioimpl implements IPeliculaservicio {

	@Autowired
	IPelicularepositorio repo;
	
	@Override
	public List<Pelicula> listar() {
		return repo.findAll();
	}

	@Override
	public Pelicula registrar(Pelicula Pelicula) {
		return repo.save(Pelicula);
	}

	@Override
	public Pelicula actualizar(Pelicula Pelicula) {
		return repo.save(Pelicula);
	}

	@Override
	public void eliminar(Integer codigo) {
		repo.deleteById(codigo);
	}

	@Override
	public Pelicula ListarPorId(Integer codigo) {
		return repo.findById(codigo).orElse(null);
	}

}
