package com.example.demo.servicio.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.proyectopeliculas.Oferta;
import com.example.demo.repositorio.IOfertarepositorio;
import com.example.demo.servicio.IOfertaservicio;

@Service 
public class Ofertaservicioimpl implements IOfertaservicio {
	

	@Autowired
	IOfertarepositorio repo;

	@Override
	public List<Oferta> listar() {
		return repo.findAll();

	}

	@Override
	public Oferta registrar(Oferta Oferta) {
		return repo.save(Oferta);

	}

	@Override
	public Oferta actualizar(Oferta Oferta) {
		return repo.save(Oferta);
	}

	@Override
	public void eliminar(Integer codigo) {
		repo.deleteById(codigo);
		
	}

	@Override
	public Oferta ListarPorId(Integer codigo) {
		return repo.findById(codigo).orElse(null);

	}


}