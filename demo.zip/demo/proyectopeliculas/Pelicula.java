package com.example.demo.proyectopeliculas;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="pelicula")
public class Pelicula {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="idPelicula")
	private Integer idPelicula;
	
	
	@Column(name="titulo", length = 100, nullable =false)
	private String titulo;
	
	@Column(name="descripcion", length = 100, nullable =false)
	private String descripcion;
	
	@Column(name="fecha")
	private String fecha;
	
	@ManyToOne
	@JoinColumn(name="idDirector")
	private Director director;
	
	@ManyToOne
	@JoinColumn(name="idCategoria")
	private Categoria categoria;
	
	@ManyToOne
	@JoinColumn(name="idUsuario")
	private Usuario usuario;
	
	@ManyToOne
	@JoinColumn(name="idActor")
	private Actor actor;

	public Integer getIdPelicula() {
		return idPelicula;
	}

	public void setIdPelicula(Integer idPelicula) {
		this.idPelicula = idPelicula;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public Director getIdDirector() {
		return director;
	}

	public void setIdDirector(Director idDirector) {
		this.director = idDirector;
	}

	public Categoria getIdCategoria() {
		return categoria;
	}

	public void setIdCategoria(Categoria idCategoria) {
		this.categoria = idCategoria;
	}

	public Usuario getIdUsuario() {
		return usuario;
	}

	public void setIdUsuario(Usuario idUsuario) {
		this.usuario = idUsuario;
	}

	public Actor getIdActor() {
		return actor;
	}

	public void setIdActor(Actor idActor) {
		this.actor = idActor;
	}
	
	
	

}
