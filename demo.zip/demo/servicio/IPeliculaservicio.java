package com.example.demo.servicio;

import java.util.List;

import com.example.demo.proyectopeliculas.Pelicula;

public interface IPeliculaservicio {
	
	List<Pelicula> listar();
	Pelicula registrar(Pelicula Pelicula);
	Pelicula actualizar(Pelicula Pelicula);
	void eliminar(Integer codigo);
	Pelicula ListarPorId(Integer codigo);

}
