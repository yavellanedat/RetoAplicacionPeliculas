package com.example.demo.servicio.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.proyectopeliculas.Actor;
import com.example.demo.repositorio.IActorrepositorio;
import com.example.demo.servicio.IActorservicio;

@Service 
public class Actorservicioimpl implements IActorservicio {
	

	@Autowired
	IActorrepositorio repo;

	@Override
	public List<Actor> listar() {
		return repo.findAll();

	}

	@Override
	public Actor registrar(Actor Actor) {
		return repo.save(Actor);

	}

	@Override
	public Actor actualizar(Actor Actor) {
		return repo.save(Actor);
	}

	@Override
	public void eliminar(Integer codigo) {
		repo.deleteById(codigo);
		
	}

	@Override
	public Actor ListarPorId(Integer codigo) {
		return repo.findById(codigo).orElse(null);

	}


}