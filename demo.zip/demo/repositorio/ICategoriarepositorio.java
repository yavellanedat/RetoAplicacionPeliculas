package com.example.demo.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.proyectopeliculas.Categoria;

public interface ICategoriarepositorio extends JpaRepository<Categoria, Integer> {

}