package com.example.demo.servicio;

import java.util.List;

import com.example.demo.proyectopeliculas.Actor;

public interface IActorservicio {
	
	List<Actor> listar();
	Actor registrar(Actor Actor);
	Actor actualizar(Actor Actor);
	void eliminar(Integer codigo);
	Actor ListarPorId(Integer codigo);

}