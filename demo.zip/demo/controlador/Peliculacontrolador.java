package com.example.demo.controlador;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.demo.proyectopeliculas.Pelicula;
import com.example.demo.servicio.IPeliculaservicio;

@RestController
@RequestMapping("/Pelicula")
public class Peliculacontrolador {
	
	@Autowired
	IPeliculaservicio service;
	
	@GetMapping
	public ResponseEntity<List<Pelicula>> listar(){
		List<Pelicula> obj = service.listar();
		return new ResponseEntity<List<Pelicula>>(obj, HttpStatus.OK);
	}
	
	@PostMapping
	public ResponseEntity<Void> registrar(@RequestBody Pelicula pelicula){
		Pelicula obj = service.registrar(pelicula);
		
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdPelicula()).toUri();
		
		return ResponseEntity.created(uri).build();
	}
	
	@PutMapping
	public ResponseEntity<Pelicula> actualizar(@RequestBody Pelicula pelicula){
		Pelicula obj = service.actualizar(pelicula);
		return new ResponseEntity<Pelicula>(obj, HttpStatus.OK);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> eliminar(@PathVariable("id")Integer id) throws Exception{
		Pelicula obj = service.ListarPorId(id);
		if(obj == null) {
			throw new Exception("No se encontro ID");
		}
		service.eliminar(id);
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Pelicula> listarPorId(@PathVariable("id") Integer codigo) throws Exception{
	Pelicula obj = service.ListarPorId(codigo);
	if(obj == null) {
		throw new Exception("No se encontro ID");
	}
	return new ResponseEntity<Pelicula>(obj, HttpStatus.OK);
}
}