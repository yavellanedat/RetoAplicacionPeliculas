package com.example.demo.servicio;

import java.util.List;

import com.example.demo.proyectopeliculas.Director;

public interface IDirectorservicio {
	
	List<Director> listar();
	Director registrar(Director Director);
	Director actualizar(Director Director);
	void eliminar(Integer codigo);
	Director ListarPorId(Integer codigo);

}