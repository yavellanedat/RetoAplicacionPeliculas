package com.example.demo.servicio;

import java.util.List;

import com.example.demo.proyectopeliculas.Categoria;

public interface ICategoriaservicio {
	
	List<Categoria> listar();
	Categoria registrar(Categoria Categoria);
	Categoria actualizar(Categoria Categoria);
	void eliminar(Integer codigo);
	Categoria ListarPorId(Integer codigo);

}