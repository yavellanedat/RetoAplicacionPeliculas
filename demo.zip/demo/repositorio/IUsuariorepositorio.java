package com.example.demo.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.proyectopeliculas.Usuario;

public interface IUsuariorepositorio extends JpaRepository<Usuario, Integer> {

}
