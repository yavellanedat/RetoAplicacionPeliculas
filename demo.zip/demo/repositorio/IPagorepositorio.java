package com.example.demo.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.proyectopeliculas.Pago;

public interface IPagorepositorio extends JpaRepository<Pago, Integer> {

}