package com.example.demo.servicio;

import java.util.List;

import com.example.demo.proyectopeliculas.Rol;

public interface IRolservicio {
	
	List<Rol> listar();
	Rol registrar(Rol Rol);
	Rol actualizar(Rol Rol);
	void eliminar(Integer codigo);
	Rol ListarPorId(Integer codigo);

}
