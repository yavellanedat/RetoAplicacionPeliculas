package com.example.demo.servicio;

import java.util.List;

import com.example.demo.proyectopeliculas.Oferta;

public interface IOfertaservicio {
	
	List<Oferta> listar();
	Oferta registrar(Oferta Oferta);
	Oferta actualizar(Oferta Oferta);
	void eliminar(Integer codigo);
	Oferta ListarPorId(Integer codigo);

}